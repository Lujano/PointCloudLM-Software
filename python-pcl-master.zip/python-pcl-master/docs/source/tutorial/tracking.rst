Tracking Tutorials
==================

Tracking Example
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In this tutorial, we will learn how to construct and run a Moving Least Squares (MLS) algorithm to obtain smoothed XYZ coordinates and normals.

* Original Page : None  (tutorials/sources/tracking/tracking_sample.cpp)
* TestCode : None