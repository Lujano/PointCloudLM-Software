KdTree Tutorials
================

How to use a KdTree to search
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In this tutorial, we will learn how to search using the nearest neighbor method for k-d trees

* `Original <http://pointclouds.org/documentation/tutorials/kdtree_search.php#kdtree-search>`_ \
* TestCode : examples/official/kdtree/kdtree_search.py
